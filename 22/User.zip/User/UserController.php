<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\validator;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware("auth");
    }
    public function userHome()
    {
        return view("user.dashboard");
    }    
    public function profile()
    {
        $user=User::find(Auth::user()->id);
        return view('user.view-profile')->with(['user'=>$user]);
    }
    public function editProfile($id)
    {
        $user=User::find($id);
        return view('user.edit-profile')->with(['user'=>$user]);
    
    }
    protected function validator(array $data): \Illuminate\Contracts\Validation\Validator
    {
        return Validator::make($data,[
            'name' => ['required','string','max:255'],
        ]);
    }
    public function uProfile(Request $request)
    {
        $this->validator($request->all())->validate();
        $user = Auth::user();
        $user->name = $request->name;
        $user->save();
        return redirect()->route('profile');
    }
}
