<footer class="footer">
    <p>&copy; 2024 Laravel App</p>
</footer>