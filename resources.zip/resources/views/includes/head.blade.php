<head>
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="stylesheet" href="https://www.phptutorial.net/app/css/style.css">
    <link rel="stylesheet" href="{{asset('css/style.css')}}"></link>
    <link rel="stylesheet" href="{{asset('custom_style.css')}}"/>
</head>