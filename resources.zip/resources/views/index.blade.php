@extends('layouts.master')

@section('title', 'Home')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1>Welcome to Laravel App</h1>
            <p>This is the home page.</p>
        </div>
    </div>
@endsection